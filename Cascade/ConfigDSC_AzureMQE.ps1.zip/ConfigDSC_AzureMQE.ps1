Configuration standardMQE{
    param
    (
        [Parameter()]
        [System.String[]]
        $NodeName = 'localhost'
    )

    # Import the module that contains the resources we're using.
    Import-DscResource -ModuleName PsDesiredStateConfiguration
    Import-DscResource -ModuleName xFirefox
    Import-DscResource -ModuleName xChrome
    Import-DSCResource -ModuleName xTimeZone

    Node $NodeName
    {
        # réglage de l'heure
        xTimeZone TimeZoneExample
        {
            IsSingleInstance = 'Yes'
            TimeZone         = 'Romance Standard Time'
        }

        # installation de Firefox
        MSFT_xFirefox firefox
        {
        VersionNumber = 'latest'
        Language = 'fr'
        OS = 'win64'
        LocalPath = 'C:\temp\FirefoxSetup.exe'
        }
    
        # installation de Chrome
        # MSFT_xChrome chrome
        # {
        #     Language = 'fr'
        #     LocalPath = 'C:\temp\GoogleChromeStandaloneEnterprise.msi'
        # }
    }

}